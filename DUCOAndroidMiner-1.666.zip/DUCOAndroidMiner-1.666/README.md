# DUCOAndroidMiner

Standalone multithreaded miner of DUCO for android.

# Frequent Questions:
Why interface is shit? Cuz I don't care.
